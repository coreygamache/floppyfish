/*
  Motor.cpp
  associated .cpp file for the Motor example class
  this file contains the body of each class function (where the bulk of the code goes)
*/

#ifndef Motor_h
#define Motor_h

//the standard Arduino library is added by default to each sketch created with the Arduino software
//it is not added to libraries by default however, so we must include it here manually
#include "Arduino.h"

//the following lines create a class with the name specified (Motor in this case)
//inside the class definition are definitions of all the functions and variables associated with the class
class Motor
{

  /* public classes and variables can be accessed/executed from anywhere in a program
   * private classes and variables can only be accessed/executed from within the class definition
   *  generally variables should be private, and only able to be modified from outside of the class through the use of public functions
   * this is the purpose of the get and set functions; they allow for modification of the private variables without allowing a user to access them directly
   * don't worry too much about this now, the important thing to take away is it's good practice to make variables private and provide public get and set functions to manipulate them (even though it is more work) */

  public:
    Motor(int fPin, int rPin);
    int getFwdPin();
    int getRevPin();
    void setFwdPin(int pin);
    void setRevPin(int pin);
    void forward();
    void forward(int time);
    void pwmForward(int pwm);
    void reverse();
    void reverse(int time);
    void pwmReverse(int pwm);
    void stop();
  private:
    int _fwdPin;
    int _revPin;
};

#endif