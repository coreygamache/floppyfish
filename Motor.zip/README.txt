TO INSTALL AND USE THE MOTOR EXAMPLE CLASS:

1. Copy the Motor folder in this zip file into your Arduino libraries folder. It is found in Documents/Arduino/libraries (C:\Users\YOUR NAME HERE\Documents\Arduino)

2. Include the Motor class at the beginning of your sketch by adding the following at the very beginning of your code:

#include <Motor.h>

3. Create a motor type variable in your sketch using the template Motor variableName(forwardPin, reversePin), i.e.

Motor motor1(3, 5);

This will create a new variable called motor1 of type Motor with the forward pin set as pin 3 and reverse pin set as pin 5.

4. Use various class functions by typing your motor variable name followed by a period then the function name, i.e.

motor1.forward();