/*
  Motor.cpp
  associated .cpp file for the Motor example class
  this file contains the body of each class function (where the bulk of the code goes)
*/

//the standard Arduino library is added by default to each sketch created with the Arduino software
//it is not added to libraries by default however, so we must include it here manually
#include "Arduino.h"

//we must also include the header (.h) file for the class that we are creating
#include "Motor.h"

//this is the constructor function. it will be executed whenever a Motor class type variable is created
//the fact that it takes two integers as arguments means two integers must be provided whenever a Motor class type variable is created
Motor::Motor(int fPin, int rPin)
{
  pinMode(fPin, OUTPUT);
  pinMode(rPin, OUTPUT);
  _fwdPin = fPin;
  _revPin = rPin;
}

int Motor::getFwdPin()
{
  return _fwdPin;
}

int Motor::getRevPin()
{
  return _revPin;
}

void Motor::setFwdPin(int pin)
{
  _fwdPin = pin;
}

void Motor::setRevPin(int pin)
{
  _revPin = pin;
}

void Motor::forward()
{
  digitalWrite(_revPin, LOW);
  digitalWrite(_fwdPin, HIGH);
}

void Motor::forward(int time)
{
  digitalWrite(_revPin, LOW);
  digitalWrite(_fwdPin, HIGH);
  delay(time);
  digitalWrite(_fwdPin, LOW);
}

void Motor::reverse()
{
  digitalWrite(_fwdPin, LOW);
  digitalWrite(_revPin, HIGH);
}

void Motor::reverse(int time)
{
  digitalWrite(_fwdPin, LOW);
  digitalWrite(_revPin, HIGH);
  delay(time);
  digitalWrite(_revPin, LOW);
}

void Motor::stop()
{
  digitalWrite(_fwdPin, LOW);
  digitalWrite(_revPin, LOW);
}